package com.dbc.pessoaapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PessoaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
